package com.notro.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Foreground service that keeps listening (while the internet is on) and only reacts
 * after it hears the wake word "NoTrO".
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.notro.assistant.STOP"
        const val ACTION_FORCE_LISTEN = "com.notro.assistant.FORCE_LISTEN"
        private const val CHANNEL_ID = "notro_listening"
        private const val NOTIF_ID = 7

        @Volatile
        var instance: AssistantService? = null

        private val WAKE = Regex("""\b(notro|no tro|no throw|no trow|notrow|nitro|nutro|notre)\b""")

        /** Lower-case ASCII letters, digits and single spaces only. */
        fun normalize(s: String): String =
            s.lowercase(Locale.US)
                .replace(Regex("[^a-z0-9 ]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()

        /** Called by the accessibility service after a 3-second volume hold. */
        fun poke(context: Context) {
            val running = instance
            if (running != null) {
                running.forceListen()
                return
            }
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, AssistantService::class.java).setAction(ACTION_FORCE_LISTEN)
                )
            } catch (e: Exception) {
                // Android may refuse to start a microphone service from the background.
            }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: RoboVoice
    private lateinit var commands: CommandExecutor
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var online = false
    private var destroyed = false
    private var speechPending = 0
    private var activeUntil = 0L
    private var lastStatus = ""
    private val restart = Runnable { resumeListening() }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            main.post {
                online = true
                status("Say \"NoTrO\"")
                resumeListening()
            }
        }

        override fun onLost(network: Network) {
            main.post {
                online = false
                stopListening()
                status("Waiting for the internet…")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        startForeground(
            NOTIF_ID,
            buildNotification("Starting…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        voice = RoboVoice(this)
        commands = CommandExecutor(this)

        val cm = getSystemService(ConnectivityManager::class.java)
        online = cm.getNetworkCapabilities(cm.activeNetwork)
            ?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        try {
            cm.registerDefaultNetworkCallback(netCallback)
        } catch (e: Exception) {
        }
        status(if (online) "Say \"NoTrO\"" else "Waiting for the internet…")
        if (online) resumeListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_FORCE_LISTEN -> forceListen()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        destroyed = true
        instance = null
        main.removeCallbacksAndMessages(null)
        try {
            getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(netCallback)
        } catch (e: Exception) {
        }
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
        voice.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- speaking

    /** Speaks [text] (the microphone is paused meanwhile), then runs [after]. */
    fun say(text: String, after: (() -> Unit)? = null) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { say(text, after) }
            return
        }
        speechPending++
        stopListening()
        voice.speak(speakable(text)) {
            speechPending--
            try {
                after?.invoke()
            } catch (e: Exception) {
            }
            if (speechPending == 0) scheduleRestart(500)
        }
    }

    private fun speakable(t: String): String =
        t.replace("NoTrO", "Notro", ignoreCase = true).replace("Mr.", "Mister")

    // ---------------------------------------------------------------- listening

    private fun forceListen() {
        try {
            getSystemService(Vibrator::class.java)
                ?.vibrate(VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
        main.post {
            stopListening()
            try {
                recognizer?.destroy()
            } catch (e: Exception) {
            }
            recognizer = null
            resumeListening()
        }
    }

    private fun resumeListening() {
        if (destroyed || !online || speechPending > 0 || listening) return
        startListening()
    }

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restart)
        main.postDelayed(restart, delayMs)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("Speech recognition is not available on this phone")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status("Microphone permission is missing")
            return
        }
        try {
            val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            listening = true
            r.startListening(intent)
            status("Say \"NoTrO\"")
        } catch (e: Exception) {
            listening = false
            try {
                recognizer?.destroy()
            } catch (e: Exception) {
            }
            recognizer = null
            scheduleRestart(1500)
        }
    }

    private fun stopListening() {
        main.removeCallbacks(restart)
        if (listening) {
            listening = false
            try {
                recognizer?.cancel()
            } catch (e: Exception) {
            }
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            if (!listening) return
            listening = false
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            handleResults(list)
            if (speechPending == 0) scheduleRestart(150)
        }

        override fun onError(error: Int) {
            if (!listening) return
            listening = false
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> scheduleRestart(200)

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    try {
                        recognizer?.destroy()
                    } catch (e: Exception) {
                    }
                    recognizer = null
                    scheduleRestart(1200)
                }

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    status("Microphone permission is missing")

                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> scheduleRestart(2000)

                else -> scheduleRestart(1000)
            }
        }
    }

    // ---------------------------------------------------------------- commands

    private fun handleResults(list: List<String>) {
        val texts = list.map { normalize(it) }.filter { it.isNotEmpty() }
        if (texts.isEmpty()) return
        val now = SystemClock.elapsedRealtime()

        for (text in texts) {
            val m = WAKE.find(text) ?: continue
            val after = text.substring(m.range.last + 1).trim()
            val before = text.substring(0, m.range.first).trim()
            val cmd = if (after.isNotEmpty()) after else before
            if (cmd.isEmpty()) {
                activeUntil = now + 8000
                say("Sir, Mister Notro.")
            } else {
                activeUntil = 0
                commands.run(cmd)
            }
            return
        }

        // The wake word was said alone a moment ago: the next sentence is the command.
        if (now < activeUntil) {
            activeUntil = 0
            commands.run(texts.first())
        }
    }

    // ---------------------------------------------------------------- notification

    private fun status(text: String) {
        if (text == lastStatus) return
        lastStatus = text
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        } catch (e: Exception) {
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "NoTrO assistant", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("NoTrO")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .build()
    }
}
