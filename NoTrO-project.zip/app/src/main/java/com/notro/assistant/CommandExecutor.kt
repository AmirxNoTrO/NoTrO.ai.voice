package com.notro.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.ContactsContract
import java.util.Locale

/** Turns a spoken command (already lower-cased, without the wake word) into an action. */
class CommandExecutor(private val service: AssistantService) {

    private val ctx: Context = service

    private val whoAmI = Regex("""\bwho am i\b""")
    private val lock = Regex("""\b(lock|look)\s+(the\s+)?screen\b""")
    private val flash = Regex("""\b(flash ?light|torch)\b""")
    private val flashOff = Regex("""\b(off|disable|close|stop)\b""")
    private val selfie = Regex("""\b(selfie|self ie|selfy)\b""")
    private val call = Regex("""^(?:call|phone|dial)(?: to)?\s+(.+)$""")
    private val open = Regex("""^(?:open|launch|start)\s+(.+)$""")
    private val search = Regex("""^(?:search|google)(?: for| about)?\s+(.+)$""")

    private val aliases = mapOf(
        "whatsapp" to "com.whatsapp",
        "telegram" to "org.telegram.messenger",
        "instagram" to "com.instagram.android",
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm",
        "play store" to "com.android.vending",
        "spotify" to "com.spotify.music"
    )

    fun run(cmd: String) {
        when {
            whoAmI.containsMatchIn(cmd) -> service.say("You are NoTrO.")
            lock.containsMatchIn(cmd) || cmd == "lock" -> lockScreen()
            flash.containsMatchIn(cmd) -> flashlight(!flashOff.containsMatchIn(cmd))
            selfie.containsMatchIn(cmd) -> takeSelfie()
            else -> {
                call.find(cmd)?.let { callContact(it.groupValues[1].trim()); return }
                open.find(cmd)?.let { openApp(it.groupValues[1].trim()); return }
                search.find(cmd)?.let { searchGoogle(it.groupValues[1].trim()); return }
                service.say("Sorry, Sir. I did not understand that command.")
            }
        }
    }

    // ---------------------------------------------------------------- actions

    private fun lockScreen() {
        if (NoTrOAccessibilityService.instance == null) {
            service.say("Please enable the accessibility service first, Sir.")
            return
        }
        service.say("Locking the screen, Sir.") { NoTrOAccessibilityService.lockScreen() }
    }

    private fun flashlight(on: Boolean) {
        try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                val ch = cm.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            if (id == null) {
                service.say("This phone has no flashlight, Sir.")
                return
            }
            cm.setTorchMode(id, on)
            service.say(if (on) "The flashlight is on, Sir." else "The flashlight is off, Sir.")
        } catch (e: Exception) {
            service.say("I could not control the flashlight, Sir.")
        }
    }

    private fun takeSelfie() {
        if (!launch(Intent(ctx, SelfieActivity::class.java))) {
            service.say("I could not open the camera, Sir.")
        }
    }

    private fun callContact(name: String) {
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            service.say("I need the phone permission, Sir.")
            return
        }
        val digits = name.replace(" ", "")
        val number: String? = if (digits.length >= 3 && digits.all { it.isDigit() }) {
            digits
        } else {
            if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                service.say("I need the contacts permission, Sir.")
                return
            }
            findNumber(name)
        }
        if (number == null) {
            service.say("I could not find $name in your contacts, Sir.")
            return
        }
        service.say("Calling $name, Sir.") {
            launch(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)))
        }
    }

    private fun openApp(raw: String) {
        val name = raw.removePrefix("the ").removeSuffix(" application").removeSuffix(" app").trim()
        val intent = findLaunchIntent(name)
        if (intent == null) {
            service.say("I could not find $name on this phone, Sir.")
            return
        }
        service.say("Opening $name, Sir.") { launch(intent) }
    }

    private fun searchGoogle(query: String) {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        service.say("Searching Google for $query, Sir.") {
            launch(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // The accessibility service is the most reliable context for starting activities from the background.
        val c: Context = NoTrOAccessibilityService.instance ?: ctx
        c.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    /** Finds a phone number by contact name (exact, partial, then close spelling). */
    private fun findNumber(query: String): String? {
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        var best: String? = null
        var bestScore = Int.MAX_VALUE
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val n = AssistantService.normalize(name)
                if (n.isEmpty()) continue
                val score = when {
                    n == query -> 0
                    n.startsWith(query) || n.split(' ').any { it == query } -> 1
                    n.contains(query) -> 2
                    else -> {
                        val d = levenshtein(n, query)
                        if (d <= maxOf(1, query.length / 4)) 3 + d else Int.MAX_VALUE
                    }
                }
                if (score < bestScore) {
                    bestScore = score
                    best = number
                }
            }
        }
        return best
    }

    private fun findLaunchIntent(name: String): Intent? {
        val pm = ctx.packageManager
        aliases[name]?.let { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let { return it }
        }
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        var best: ResolveInfo? = null
        var bestScore = 0
        for (ri in pm.queryIntentActivities(main, 0)) {
            val label = AssistantService.normalize(ri.loadLabel(pm).toString())
            if (label.isEmpty()) continue
            val score = when {
                label == name -> 4
                label.startsWith(name) -> 3
                label.contains(name) -> 2
                label.length >= 3 && name.contains(label) -> 1
                else -> 0
            }
            if (score > bestScore) {
                bestScore = score
                best = ri
            }
        }
        val hit = best ?: return null
        return Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(hit.activityInfo.packageName, hit.activityInfo.name)
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }
}
