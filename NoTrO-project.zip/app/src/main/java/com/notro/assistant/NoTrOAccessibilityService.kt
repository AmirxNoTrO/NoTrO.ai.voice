package com.notro.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Two jobs:
 *  1. Lock the screen on request ("NoTrO, lock screen").
 *  2. Detect a 3-second hold of a volume button, in any app and at any volume level,
 *     and wake the assistant. Key events are never consumed, so the volume still changes normally.
 */
class NoTrOAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NoTrOAccessibilityService? = null

        private const val HOLD_MS = 3000L

        fun lockScreen(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var heldKey = 0
    private val holdRunnable = Runnable { AssistantService.poke(this) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        handler.removeCallbacks(holdRunnable)
        instance = null
        return super.onUnbind(intent)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0 && heldKey == 0) {
                    heldKey = code
                    handler.postDelayed(holdRunnable, HOLD_MS)
                }
            }
            KeyEvent.ACTION_UP -> {
                if (code == heldKey) {
                    handler.removeCallbacks(holdRunnable)
                    heldKey = 0
                }
            }
        }
        return false
    }
}
