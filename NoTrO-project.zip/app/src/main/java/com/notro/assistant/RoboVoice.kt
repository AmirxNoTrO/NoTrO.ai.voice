package com.notro.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/**
 * A deep, British, male text-to-speech voice with a metallic "robot" effect
 * (comb filter + light ring modulation), in the spirit of Jarvis.
 *
 * Every callback is delivered on the main thread, even when speech fails,
 * so the rest of the app never gets stuck waiting for it.
 */
class RoboVoice(private val context: Context) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var busy = false
    private val queue = ArrayDeque<Pair<String, () -> Unit>>()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    configure()
                    ready = true
                    pump()
                } else {
                    failed = true
                    while (queue.isNotEmpty()) {
                        val (_, done) = queue.removeFirst()
                        done()
                    }
                }
            }
        }
    }

    fun speak(text: String, onDone: () -> Unit) {
        if (failed) {
            main.post { onDone() }
            return
        }
        queue.addLast(text to onDone)
        pump()
    }

    fun shutdown() {
        queue.clear()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
    }

    private fun configure() {
        val t = tts ?: return
        val r = t.setLanguage(Locale.UK)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.US)
        }
        try {
            val voices = t.voices
            if (voices != null) {
                val preferred = listOf("en-gb-x-gbd", "en-gb-x-gbb", "en-us-x-iol", "en-us-x-iom", "en-us-x-tpd")
                var chosen: Voice? = preferred.firstNotNullOfOrNull { p ->
                    voices.firstOrNull { it.name.startsWith(p) }
                }
                if (chosen == null) {
                    chosen = voices.firstOrNull {
                        it.locale.language == "en" &&
                            it.name.contains("male", ignoreCase = true) &&
                            !it.name.contains("female", ignoreCase = true)
                    }
                }
                if (chosen != null) t.voice = chosen
            }
        } catch (e: Exception) {
        }
        t.setPitch(0.62f)
        t.setSpeechRate(0.95f)
    }

    private fun pump() {
        if (busy || !ready || queue.isEmpty()) return
        val (text, done) = queue.removeFirst()
        busy = true
        render(text) {
            busy = false
            done()
            pump()
        }
    }

    private fun render(text: String, finished: () -> Unit) {
        val t = tts
        if (t == null) {
            finished()
            return
        }
        val id = "notro_${System.nanoTime()}"
        val file = File(context.cacheDir, "$id.wav")
        val settled = AtomicBoolean(false)
        val complete = { if (settled.compareAndSet(false, true)) finished() }
        val failOver = { if (settled.compareAndSet(false, true)) fallback(text, finished) }
        val watchdog = Runnable { failOver() }
        main.postDelayed(watchdog, 8000)

        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                if (utteranceId != id) return
                main.post { main.removeCallbacks(watchdog) }
                Thread {
                    val ok = try {
                        playEffected(file)
                    } catch (e: Exception) {
                        false
                    }
                    file.delete()
                    main.post { if (ok) complete() else failOver() }
                }.start()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId != id) return
                main.post {
                    main.removeCallbacks(watchdog)
                    failOver()
                }
            }
        })

        if (t.synthesizeToFile(text, Bundle(), file, id) != TextToSpeech.SUCCESS) {
            main.removeCallbacks(watchdog)
            failOver()
        }
    }

    /** Plain TTS playback, used only if the effect pipeline fails. */
    private fun fallback(text: String, finished: () -> Unit) {
        val t = tts
        if (t == null) {
            finished()
            return
        }
        val id = "fallback_${System.nanoTime()}"
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                main.post { finished() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { finished() }
            }
        })
        if (t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) {
            finished()
        }
    }

    /** Reads the synthesized WAV, applies the robot effect and plays it. Blocks until playback ends. */
    private fun playEffected(file: File): Boolean {
        val bytes = file.readBytes()
        if (bytes.size < 48) return false
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val channels = bb.getShort(22).toInt()
        val rate = bb.getInt(24)
        val bits = bb.getShort(34).toInt()
        if (bits != 16 || channels !in 1..2 || rate < 8000) return false

        var pos = 12
        var start = -1
        var len = 0
        while (pos + 8 <= bytes.size) {
            val chunkId = String(bytes, pos, 4, Charsets.US_ASCII)
            val chunkLen = bb.getInt(pos + 4)
            if (chunkId == "data") {
                start = pos + 8
                val remaining = bytes.size - start
                len = if (chunkLen < 0 || chunkLen > remaining) remaining else chunkLen
                break
            }
            if (chunkLen < 0) return false
            pos += 8 + chunkLen + (chunkLen and 1)
        }
        if (start < 0 || len < 2) return false

        val n = len / 2
        val pcm = ShortArray(n)
        ByteBuffer.wrap(bytes, start, n * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(pcm)

        // Metallic comb filter (about 6.5 ms feedback delay).
        val delay = max(1, (rate * 0.0065).toInt()) * channels
        val buf = FloatArray(n)
        for (i in 0 until n) {
            val x = pcm[i] / 32768f
            buf[i] = x + if (i >= delay) buf[i - delay] * 0.55f else 0f
        }

        // Light ring modulation for the synthetic edge.
        val w = 2.0 * PI * 38.0 / rate
        var peak = 0f
        for (i in 0 until n) {
            val ring = buf[i] * sin(w * (i / channels)).toFloat()
            val y = buf[i] * 0.7f + ring * 0.3f
            buf[i] = y
            peak = max(peak, abs(y))
        }

        val gain = if (peak > 0f) 0.9f / peak else 1f
        val out = ShortArray(n) { (buf[it] * gain * 32767f).toInt().coerceIn(-32768, 32767).toShort() }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(
                        if (channels == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
                    )
                    .build()
            )
            .setBufferSizeInBytes(out.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        try {
            track.write(out, 0, out.size)
            val frames = n / channels
            track.play()
            val deadline = SystemClock.elapsedRealtime() + frames * 1000L / rate + 1500
            while (SystemClock.elapsedRealtime() < deadline && track.playbackHeadPosition < frames - 16) {
                Thread.sleep(30)
            }
            Thread.sleep(80)
            try {
                track.stop()
            } catch (e: Exception) {
            }
        } finally {
            track.release()
        }
        return true
    }
}
