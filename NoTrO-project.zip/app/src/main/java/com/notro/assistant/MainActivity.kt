package com.notro.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Setup screen: permissions, accessibility service, and start / stop of the assistant. */
class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private val handler = Handler(Looper.getMainLooper())

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    private val runtimePermissions: Array<String>
        get() {
            val list = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.CAMERA
            )
            if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
            return list.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val d = resources.displayMetrics.density
        val pad = (18 * d).toInt()
        val accent = Color.parseColor("#4FC3F7")
        val textColor = Color.parseColor("#E6F6FF")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "NoTrO"
            textSize = 34f
            setTextColor(accent)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Voice assistant · say \"NoTrO\" to wake it"
            textSize = 14f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        })

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(textColor)
            setPadding(0, 0, 0, pad)
        }
        root.addView(status)

        fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(button("1 · Grant permissions") { permissionLauncher.launch(runtimePermissions) })
        root.addView(button("2 · Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("3 · Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find NoTrO in the list and turn it on", Toast.LENGTH_LONG).show()
        })
        root.addView(button("4 · Disable battery optimization") {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        })

        toggle = button("Start assistant") { toggleService() }
        root.addView(toggle)

        root.addView(TextView(this).apply {
            text = """
                Commands (say NoTrO first):
                • call to <name>
                • turn on the flashlight
                • take a selfie
                • open <app name>
                • search <anything>
                • who am I
                • lock screen

                Hold a volume button for 3 seconds to wake the listener.
            """.trimIndent()
            textSize = 14f
            setTextColor(textColor)
            setPadding(0, pad, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun toggleService() {
        val running = AssistantService.instance != null
        if (running) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
        } else if (!granted(Manifest.permission.RECORD_AUDIO)) {
            Toast.makeText(this, "Grant the microphone permission first", Toast.LENGTH_LONG).show()
            permissionLauncher.launch(runtimePermissions)
            return
        } else {
            ContextCompat.startForegroundService(this, Intent(this, AssistantService::class.java))
        }
        handler.postDelayed({ refresh() }, 700)
    }

    private fun refresh() {
        fun mark(ok: Boolean, label: String) = (if (ok) "✅ " else "❌ ") + label

        val battery = getSystemService(PowerManager::class.java)
            .isIgnoringBatteryOptimizations(packageName)
        val running = AssistantService.instance != null

        status.text = listOf(
            mark(granted(Manifest.permission.RECORD_AUDIO), "Microphone"),
            mark(granted(Manifest.permission.READ_CONTACTS), "Contacts"),
            mark(granted(Manifest.permission.CALL_PHONE), "Phone calls"),
            mark(granted(Manifest.permission.CAMERA), "Camera"),
            mark(Settings.canDrawOverlays(this), "Display over other apps"),
            mark(NoTrOAccessibilityService.instance != null, "Accessibility service"),
            mark(battery, "Battery optimization off"),
            mark(running, "Assistant running")
        ).joinToString("\n")

        toggle.text = if (running) "Stop assistant" else "Start assistant"
    }
}
